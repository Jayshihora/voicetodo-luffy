import React, { memo, useState, useRef, useEffect } from 'react';
import { Todo } from '../types';

interface TodoItemProps {
  todo: Todo;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  onBreakdown: (id: string, text: string) => void;
  onEdit: (id: string, newText: string, newDeadline?: string, newTime?: string, newReminderOffset?: number) => void;
  onToggleStar: (id: string) => void;
  isBreakingDown: boolean;
}

const TodoItem: React.FC<TodoItemProps> = ({ 
  todo, 
  onToggle, 
  onDelete, 
  onBreakdown, 
  onEdit,
  onToggleStar,
  isBreakingDown 
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(todo.text);
  const [editDate, setEditDate] = useState(todo.deadline || '');
  const [editTime, setEditTime] = useState(todo.deadlineTime || '');
  const [editReminder, setEditReminder] = useState<number>(todo.reminderOffset || 0);
  
  const inputRef = useRef<HTMLInputElement>(null);

  // Only initialize state when entering edit mode, do not reset while editing if props change
  useEffect(() => {
    if (isEditing) {
      setEditText(todo.text);
      setEditDate(todo.deadline || '');
      setEditTime(todo.deadlineTime || '');
      setEditReminder(todo.reminderOffset || 0);
      // Small delay to ensure render is complete before focus
      const timer = setTimeout(() => inputRef.current?.focus(), 50);
      return () => clearTimeout(timer);
    }
  }, [isEditing]); // Removed 'todo' dependency to prevent overwriting user input

  const handleSave = () => {
    if (editText.trim()) {
      onEdit(
        todo.id, 
        editText.trim(), 
        editDate || undefined, 
        editTime || undefined,
        editReminder === 0 ? undefined : editReminder
      );
    }
    setIsEditing(false);
  };

  const handleCancel = () => {
    setIsEditing(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleSave();
    if (e.key === 'Escape') handleCancel();
  };

  const getDeadlineStatus = (dateStr?: string, timeStr?: string) => {
    if (!dateStr) return null;
    
    const [y, m, d] = dateStr.split('-').map(Number);
    // specific parsing ensures local time midnight
    const deadlineDate = new Date(y, m - 1, d);
    
    if (timeStr) {
      const [hours, minutes] = timeStr.split(':').map(Number);
      deadlineDate.setHours(hours, minutes, 0, 0);
    } else {
      deadlineDate.setHours(23, 59, 59, 999);
    }

    const now = new Date();
    const timeDisplay = timeStr ? new Date(`2000-01-01T${timeStr}`).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) : '';

    if (deadlineDate < now && !todo.completed) {
       return { 
         text: timeStr ? `OVERDUE • ${timeDisplay}` : 'OVERDUE', 
         color: 'text-red-600 font-black',
         bg: 'bg-red-50 border-red-200'
       };
    }

    const today = new Date();
    today.setHours(0,0,0,0);
    const targetDay = new Date(deadlineDate);
    targetDay.setHours(0,0,0,0);
    
    const dayDiff = Math.ceil((targetDay.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

    if (dayDiff === 0) {
      return { 
        text: timeStr ? `TODAY • ${timeDisplay}` : 'TODAY', 
        color: 'text-amber-600 font-bold',
        bg: 'bg-amber-50 border-amber-200'
      };
    }
    if (dayDiff === 1) {
      return { 
        text: timeStr ? `TOMORROW • ${timeDisplay}` : 'TOMORROW', 
        color: 'text-blue-600 font-bold',
        bg: 'bg-blue-50 border-blue-200'
      };
    }
    
    return { 
      text: `${deadlineDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}${timeStr ? ' • ' + timeDisplay : ''}`, 
      color: 'text-slate-500 font-bold',
      bg: 'bg-white border-slate-200'
    };
  };

  const deadlineInfo = getDeadlineStatus(todo.deadline, todo.deadlineTime);

  return (
    <div className={`group relative p-4 rounded-xl transition-all duration-300 animate-slide-up mb-3 border-2 hover:shadow-lg ${
      todo.completed 
        ? 'bg-slate-50 border-slate-200 opacity-70 grayscale' 
        : 'bg-white border-amber-100 shadow-sm hover:border-amber-300'
    }`}>
      <div className="flex items-start gap-4">
        
        {/* Custom Checkbox */}
        <button
          onClick={() => onToggle(todo.id)}
          className={`mt-1 w-6 h-6 rounded-full border-2 flex-shrink-0 flex items-center justify-center transition-all duration-200 ${
            todo.completed
              ? 'bg-slate-400 border-slate-400'
              : 'border-slate-300 hover:border-red-500'
          }`}
        >
          {todo.completed && (
            <svg className="w-3.5 h-3.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" d="M5 13l4 4L19 7" />
            </svg>
          )}
        </button>
        
        <div className="flex flex-col gap-1.5 w-full min-w-0">
          {isEditing ? (
            <div className="flex flex-col gap-3 w-full animate-fade-in">
              <input
                ref={inputRef}
                type="text"
                value={editText}
                onChange={(e) => setEditText(e.target.value)}
                onKeyDown={handleKeyDown}
                className="text-lg text-slate-900 w-full bg-transparent border-b-2 border-red-200 pb-1 focus:outline-none focus:border-red-500 transition-colors font-bold"
                placeholder="Task description"
              />
              <div className="flex gap-2 flex-wrap items-center bg-slate-50 p-2 rounded-lg">
                <label className="flex items-center gap-1 bg-white px-2 py-1 rounded border border-slate-200 shadow-sm cursor-pointer hover:border-red-300 transition-colors">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Date</span>
                  <input 
                    type="date" 
                    value={editDate} 
                    onChange={(e) => setEditDate(e.target.value)}
                    className="text-xs text-slate-700 focus:outline-none bg-transparent"
                  />
                </label>
                
                <label className="flex items-center gap-1 bg-white px-2 py-1 rounded border border-slate-200 shadow-sm cursor-pointer hover:border-red-300 transition-colors">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Time</span>
                  <input 
                    type="time" 
                    value={editTime} 
                    onChange={(e) => setEditTime(e.target.value)}
                    className="text-xs text-slate-700 focus:outline-none bg-transparent"
                  />
                </label>

                <select
                  value={editReminder}
                  onChange={(e) => setEditReminder(Number(e.target.value))}
                  className="text-xs bg-white rounded px-2 py-1.5 text-slate-700 focus:outline-none border border-slate-200 shadow-sm cursor-pointer hover:border-red-300 transition-colors"
                >
                  <option value={0}>No Alert</option>
                  <option value={15}>15m before</option>
                  <option value={60}>1h before</option>
                  <option value={1440}>1d before</option>
                </select>
                <div className="flex gap-1 ml-auto">
                   <button onClick={handleCancel} className="text-xs font-bold text-slate-500 hover:bg-slate-200 px-3 py-1.5 rounded uppercase transition-colors">Cancel</button>
                   <button onClick={handleSave} className="text-xs font-bold text-white bg-red-500 px-3 py-1.5 rounded shadow-sm uppercase hover:bg-red-600 transition-colors">Save</button>
                </div>
              </div>
            </div>
          ) : (
            <>
              <div className="flex items-start justify-between gap-2">
                <span 
                  onClick={() => !todo.completed && setIsEditing(true)}
                  className={`text-base leading-snug cursor-text transition-all font-bold ${
                    todo.completed ? 'text-slate-400 line-through decoration-2 decoration-slate-300' : 'text-slate-800'
                  }`}
                >
                  {todo.text}
                </span>
                
                {/* Icons Container */}
                <div className="flex items-center gap-1 shrink-0">
                   {/* Star Toggle */}
                   <button
                    onClick={(e) => { e.stopPropagation(); onToggleStar(todo.id); }}
                    className={`p-1.5 rounded-full transition-all ${
                      todo.isStarred 
                      ? 'text-yellow-400 bg-yellow-50' 
                      : 'text-slate-300 hover:text-yellow-400 opacity-0 group-hover:opacity-100'
                    }`}
                  >
                    <svg className="w-5 h-5" fill={todo.isStarred ? "currentColor" : "none"} stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
                    </svg>
                  </button>

                  {/* Breakdown Button */}
                  {!todo.completed && (
                    <button
                      onClick={(e) => { e.stopPropagation(); onBreakdown(todo.id, todo.text); }}
                      disabled={isBreakingDown}
                      className={`flex items-center gap-1 px-2 py-1 text-xs font-bold rounded-full transition-colors border ${
                        isBreakingDown 
                        ? 'bg-blue-100 text-blue-700 border-blue-200'
                        : 'text-blue-600 bg-blue-50 border-blue-100 hover:bg-blue-100'
                      }`}
                      title="Use AI to break down this task"
                    >
                      {isBreakingDown ? (
                        <svg className="animate-spin w-3 h-3" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                      ) : (
                        <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                           <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.384-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
                        </svg>
                      )}
                      <span className="hidden sm:inline">Breakdown</span>
                    </button>
                  )}

                  {/* Edit Button */}
                  {!todo.completed && (
                    <button
                      onClick={(e) => { e.stopPropagation(); setIsEditing(true); }}
                      className="p-1.5 text-slate-300 hover:text-slate-800 rounded-md hover:bg-slate-100 transition-colors opacity-0 group-hover:opacity-100"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                      </svg>
                    </button>
                  )}

                  {/* Delete Button */}
                  <button
                    onClick={(e) => { e.stopPropagation(); onDelete(todo.id); }}
                    className="p-1.5 text-slate-300 hover:text-red-500 rounded-md hover:bg-red-50 transition-colors opacity-0 group-hover:opacity-100"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-3 mt-2">
                {deadlineInfo && !todo.completed && (
                  <div className={`flex items-center gap-1 px-2 py-0.5 rounded text-[10px] uppercase tracking-wide border ${deadlineInfo.bg} ${deadlineInfo.color}`}>
                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    {deadlineInfo.text}
                  </div>
                )}

                {todo.reminderOffset && !todo.completed && (
                   <div className="flex items-center gap-1 text-[10px] text-slate-400 bg-slate-50 px-2 py-0.5 rounded border border-slate-100">
                     <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                     </svg>
                     <span>
                        {todo.reminderOffset >= 60 ? `${todo.reminderOffset/60}h` : `${todo.reminderOffset}m`}
                     </span>
                   </div>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default memo(TodoItem);