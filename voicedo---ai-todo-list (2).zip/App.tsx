import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { Todo, AppState, FilterOption, SortOption } from './types';
import { extractTodosFromAudio, breakDownTask, getLuffyGuidance, Quote } from './services/geminiService';
import { requestNotificationPermission, sendNotification } from './services/notificationService';
import TodoItem from './components/TodoItem';
import VoiceInput from './components/VoiceInput';

const App: React.FC = () => {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [appState, setAppState] = useState<AppState>(AppState.IDLE);
  const [inputValue, setInputValue] = useState('');
  const [inputDate, setInputDate] = useState('');
  const [inputTime, setInputTime] = useState('');
  
  const [quote, setQuote] = useState<Quote>({ text: "I'm gonna be King of the Pirates!", author: "Monkey D. Luffy" });
  
  const [breakingDownId, setBreakingDownId] = useState<string | null>(null);
  const [hasNotificationPermission, setHasNotificationPermission] = useState(false);
  
  // View State
  const [filter, setFilter] = useState<FilterOption>('all');
  const [sort, setSort] = useState<SortOption>('smart');
  
  // Undo state
  const [deletedTodo, setDeletedTodo] = useState<Todo | null>(null);
  const [showUndo, setShowUndo] = useState(false);
  const undoTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Clear Confirm State
  const [isClearConfirming, setIsClearConfirming] = useState(false);

  // Check Notification permissions on load
  useEffect(() => {
    if ('Notification' in window && Notification.permission === 'granted') {
      setHasNotificationPermission(true);
    }
  }, []);

  // Initial quote fetch (depends on todos length roughly)
  useEffect(() => {
    const fetchQuote = async () => {
      const newQuote = await getLuffyGuidance(todos.filter(t => !t.completed).length);
      setQuote(newQuote);
    };
    fetchQuote();
  }, [todos.length]); // Fetch new quote when task count changes significantly

  const enableNotifications = async () => {
    const granted = await requestNotificationPermission();
    setHasNotificationPermission(granted);
  };

  // Notification Poller
  useEffect(() => {
    if (!hasNotificationPermission) return;

    const checkReminders = () => {
      const now = new Date();
      const nowTs = now.getTime();

      setTodos(prevTodos => {
        let hasUpdates = false;
        // Create a new array only if necessary to avoid re-renders
        const nextTodos = [...prevTodos];
        
        for (let i = 0; i < nextTodos.length; i++) {
          const todo = nextTodos[i];
          if (todo.completed || !todo.deadline || !todo.reminderOffset || todo.reminderSent) {
            continue;
          }

          const [y, m, d] = todo.deadline.split('-').map(Number);
          const deadlineDate = new Date(y, m - 1, d);
          
          if (todo.deadlineTime) {
            const [hours, minutes] = todo.deadlineTime.split(':').map(Number);
            deadlineDate.setHours(hours, minutes, 0, 0);
          } else {
             deadlineDate.setHours(9, 0, 0, 0);
          }

          const triggerTime = deadlineDate.getTime() - (todo.reminderOffset * 60 * 1000);

          if (nowTs >= triggerTime) {
             sendNotification(
               `Yo! ${todo.text}`,
               `Do it now or no meat for dinner! (Due ${todo.reminderOffset === 0 ? 'now' : `in ${todo.reminderOffset! < 60 ? todo.reminderOffset + 'm' : todo.reminderOffset! / 60 + 'h'}`})`
             );
             nextTodos[i] = { ...todo, reminderSent: true };
             hasUpdates = true;
          }
        }

        return hasUpdates ? nextTodos : prevTodos;
      });
    };

    // Check every 30 seconds
    const intervalId = setInterval(checkReminders, 30000);
    return () => clearInterval(intervalId);
  }, [hasNotificationPermission]);

  // Persist todos
  useEffect(() => {
    const saved = localStorage.getItem('voice-do-todos');
    if (saved) {
      try {
        const loadedTodos = JSON.parse(saved);
        setTodos(loadedTodos);
      } catch (e) {
        console.error("Failed to load todos", e);
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('voice-do-todos', JSON.stringify(todos));
  }, [todos]);

  const handleAddTodo = useCallback((text: string, deadline?: string, deadlineTime?: string) => {
    const newTodo: Todo = {
      id: crypto.randomUUID(),
      text: text.trim(),
      completed: false,
      createdAt: Date.now(),
      deadline: deadline || undefined,
      deadlineTime: deadlineTime || undefined,
      isStarred: false,
      reminderOffset: 0,
      reminderSent: false
    };
    setTodos(prev => [newTodo, ...prev]);
    // Switch view to ensure user sees their new task
    setFilter('all');
  }, []);

  const toggleTodo = useCallback((id: string) => {
    setTodos(prev => prev.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  }, []);

  const toggleStar = useCallback((id: string) => {
    setTodos(prev => prev.map(t => t.id === id ? { ...t, isStarred: !t.isStarred } : t));
  }, []);

  const handleEdit = useCallback((id: string, newText: string, newDeadline?: string, newTime?: string, newReminderOffset?: number) => {
    setTodos(prev => prev.map(t => t.id === id ? { 
      ...t, 
      text: newText,
      deadline: newDeadline,
      deadlineTime: newTime,
      reminderOffset: newReminderOffset,
      reminderSent: false 
    } : t));
  }, []);

  const deleteTodo = useCallback((id: string) => {
    setTodos(prev => {
      const todoToDelete = prev.find(t => t.id === id);
      if (todoToDelete) {
        setDeletedTodo(todoToDelete);
        setShowUndo(true);
        if (undoTimeoutRef.current) clearTimeout(undoTimeoutRef.current);
        undoTimeoutRef.current = setTimeout(() => {
          setShowUndo(false);
          setDeletedTodo(null);
        }, 5000);
      }
      return prev.filter(t => t.id !== id);
    });
  }, []);

  const handleUndo = useCallback(() => {
    if (deletedTodo) {
      setTodos(prev => [...prev, deletedTodo]);
      setShowUndo(false);
      setDeletedTodo(null);
      if (undoTimeoutRef.current) clearTimeout(undoTimeoutRef.current);
    }
  }, [deletedTodo]);

  const clearCompleted = useCallback(() => {
    if (isClearConfirming) {
      setTodos(prev => prev.filter(t => !t.completed));
      setIsClearConfirming(false);
    } else {
      setIsClearConfirming(true);
      setTimeout(() => setIsClearConfirming(false), 3000);
    }
  }, [isClearConfirming]);

  // Improved Breakdown handler that takes text directly to avoid expensive lookups/dependencies
  const handleBreakdown = useCallback(async (id: string, text: string) => {
    if (breakingDownId) return;

    setBreakingDownId(id);
    try {
      const subtasks = await breakDownTask(text);
      
      if (subtasks.length > 0) {
        setTodos(prev => {
          const idx = prev.findIndex(t => t.id === id);
          if (idx === -1) return prev;

          // Find the original task to copy properties
          const task = prev[idx];
          
          const newTodos = subtasks.map(st => ({
            id: crypto.randomUUID(),
            text: st.text,
            completed: false,
            createdAt: Date.now(),
            deadline: st.deadline || task.deadline,
            deadlineTime: st.deadlineTime || task.deadlineTime,
            isStarred: task.isStarred,
            reminderOffset: 0,
            reminderSent: false
          }));

          const newPrev = [...prev];
          newPrev.splice(idx, 1, ...newTodos);
          return newPrev;
        });
      }
    } catch (e) {
      console.error("Breakdown failed", e);
    } finally {
      setBreakingDownId(null);
    }
  }, [breakingDownId]); // Removed 'todos' dependency for better performance

  const handleAudioCaptured = useCallback(async (audioBlob: Blob) => {
    setAppState(AppState.PROCESSING);
    try {
      const extractedTasks = await extractTodosFromAudio(audioBlob);
      if (extractedTasks && extractedTasks.length > 0) {
          setTodos(prev => {
             const newItems = extractedTasks.map(task => ({
                id: crypto.randomUUID(),
                text: task.text,
                completed: false,
                createdAt: Date.now(),
                deadline: task.deadline || undefined,
                deadlineTime: task.deadlineTime || undefined,
                isStarred: false,
                reminderOffset: 0,
                reminderSent: false
             }));
             return [...newItems, ...prev];
          });
          setFilter('all');
      }
      setAppState(AppState.IDLE);
    } catch (error) {
      console.error("Processing failed", error);
      setAppState(AppState.ERROR);
      setTimeout(() => setAppState(AppState.IDLE), 3000);
    }
  }, []);

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputValue.trim()) {
      handleAddTodo(inputValue, inputDate, inputTime);
      setInputValue('');
      setInputDate('');
      setInputTime('');
    }
  };

  // --- Filtering & Sorting Logic ---
  const displayedTodos = useMemo(() => {
    let result = [...todos];

    if (filter === 'active') result = result.filter(t => !t.completed);
    else if (filter === 'completed') result = result.filter(t => t.completed);

    result.sort((a, b) => {
      if (sort === 'smart') {
        if (a.completed !== b.completed) return a.completed ? 1 : -1;
        if (a.isStarred !== b.isStarred) return a.isStarred ? -1 : 1;
        if (a.deadline && b.deadline) {
          // Compare combined date+time
          const dateA = new Date(`${a.deadline}T${a.deadlineTime || '23:59'}`).getTime();
          const dateB = new Date(`${b.deadline}T${b.deadlineTime || '23:59'}`).getTime();
          if (dateA !== dateB) return dateA - dateB;
        }
        if (a.deadline && !b.deadline) return -1;
        if (!a.deadline && b.deadline) return 1;
        return b.createdAt - a.createdAt;
      }
      if (sort === 'created') return b.createdAt - a.createdAt;
      if (sort === 'deadline') {
        if (!a.deadline && !b.deadline) return b.createdAt - a.createdAt;
        if (!a.deadline) return 1;
        if (!b.deadline) return -1;
        const dateA = new Date(`${a.deadline}T${a.deadlineTime || '23:59'}`).getTime();
        const dateB = new Date(`${b.deadline}T${b.deadlineTime || '23:59'}`).getTime();
        return dateA - dateB;
      }
      if (sort === 'starred') {
        if (a.isStarred !== b.isStarred) return a.isStarred ? -1 : 1;
        return b.createdAt - a.createdAt;
      }
      return 0;
    });

    return result;
  }, [todos, filter, sort]);

  const activeCount = todos.filter(t => !t.completed).length;
  const completedCount = todos.filter(t => t.completed).length;
  const totalTodos = todos.length;
  const progress = totalTodos === 0 ? 0 : Math.round((completedCount / totalTodos) * 100);
  const hasCompleted = todos.some(t => t.completed);

  const cycleSort = () => {
    const options: SortOption[] = ['smart', 'created', 'deadline', 'starred'];
    const nextIndex = (options.indexOf(sort) + 1) % options.length;
    setSort(options[nextIndex]);
  };

  return (
    <div className="min-h-screen bg-[#fef2f2] text-slate-900 flex flex-col font-sans relative bg-[url('https://www.transparenttextures.com/patterns/paper.png')]">
      
      <header className="px-6 pb-4 bg-white/80 backdrop-blur sticky top-0 z-20 border-b border-red-100 pt-2">
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center gap-3">
            {/* Straw Hat Icon */}
            <div className="relative w-14 h-14 -mt-2 drop-shadow-lg">
                <svg viewBox="0 0 100 100" className="w-full h-full">
                    <path d="M10,60 Q50,10 90,60" fill="#fbbf24" stroke="#78350f" strokeWidth="4"/>
                    <ellipse cx="50" cy="60" rx="45" ry="10" fill="#fbbf24" stroke="#78350f" strokeWidth="4"/> 
                    <path d="M24,55 Q50,20 76,55" fill="none" stroke="#ef4444" strokeWidth="6"/>
                </svg>
            </div>
            <div>
              <h1 className="text-3xl font-black text-slate-900 tracking-tight uppercase" style={{ fontFamily: 'Arial Black, sans-serif' }}>Luffy's List</h1>
              <p className="text-xs font-bold text-red-500 uppercase tracking-wider mt-0.5">
                Become the Pirate King!
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            {/* Compass Progress Indicator */}
            {totalTodos > 0 && (
              <div className="relative w-12 h-12 group cursor-default drop-shadow-md">
                {/* Compass styling */}
                <div className="absolute inset-0 rounded-full border-2 border-amber-800 opacity-20"></div>
                <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                  <path
                    className="text-amber-100"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="4"
                  />
                  <path
                    className="text-red-500 transition-all duration-1000 ease-out"
                    strokeDasharray={`${progress}, 100`}
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="4"
                    strokeLinecap="round"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-[10px] font-black text-amber-900">{progress}%</span>
                </div>
              </div>
            )}
             
             {/* Notification Icon */}
             {!hasNotificationPermission && 'Notification' in window && (
                <button onClick={enableNotifications} className="text-slate-400 hover:text-red-500 transition-colors p-1 bg-white rounded-full shadow-sm">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                  </svg>
                </button>
             )}
          </div>
        </div>

        {/* Luffy Quote Card */}
        <div className="w-full bg-gradient-to-r from-red-600 to-red-500 rounded-xl p-5 shadow-lg shadow-red-200 mb-6 text-white relative overflow-hidden border-2 border-red-700">
            {/* Decorative patterns */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-white opacity-5 rounded-full -translate-y-1/2 translate-x-1/3"></div>
            <div className="absolute bottom-0 left-0 w-20 h-20 bg-black opacity-10 rounded-full translate-y-1/3 -translate-x-1/4"></div>
            
            <div className="relative z-10 flex gap-3 items-start">
              <div className="text-4xl opacity-50">❝</div>
              <div>
                <p className="text-lg font-black leading-tight font-sans tracking-wide mb-2 uppercase italic">
                  {quote.text}
                </p>
                <p className="text-xs font-bold uppercase opacity-90 tracking-widest flex items-center gap-2 text-amber-300">
                   — {quote.author}
                </p>
              </div>
            </div>
        </div>

        {/* Controls */}
        <div className="flex items-center justify-between">
          <div className="flex bg-red-50 p-1 rounded-lg border border-red-100">
             {(['all', 'active', 'completed'] as FilterOption[]).map((f) => (
               <button
                 key={f}
                 onClick={() => setFilter(f)}
                 className={`px-3 py-1 text-xs font-bold rounded-md uppercase transition-all ${
                   filter === f 
                     ? 'bg-white text-red-600 shadow-sm ring-1 ring-red-100' 
                     : 'text-slate-400 hover:text-slate-600'
                 }`}
               >
                 {f}
               </button>
             ))}
          </div>

          <button 
            onClick={cycleSort}
            className="flex items-center gap-1 text-xs font-bold uppercase tracking-wider text-slate-400 hover:text-red-500 transition-colors px-3 py-1.5 rounded-lg hover:bg-red-50"
          >
            {sort}
            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
            </svg>
          </button>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto px-6 pb-32 no-scrollbar">
        
        {/* Add Input */}
        <form onSubmit={handleManualSubmit} className="mb-6 mt-4 z-10 relative">
          <div className="relative group shadow-sm hover:shadow-md transition-shadow rounded-xl">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="What's our next adventure?"
              className="w-full pl-4 pr-28 py-4 bg-white rounded-xl text-slate-800 placeholder-slate-400 border-2 border-slate-100 focus:outline-none focus:border-red-400 focus:ring-4 focus:ring-red-500/10 transition-all font-bold"
            />
            
            {/* Right Side Controls */}
            <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
              
              {/* Date Picker */}
              <div className="relative w-8 h-8 flex items-center justify-center text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-full transition-colors">
                <input 
                   type="date" 
                   value={inputDate}
                   onChange={(e) => setInputDate(e.target.value)}
                   className="absolute inset-0 w-full h-full z-20 opacity-0 cursor-pointer"
                   title="Add Deadline"
                />
                <svg className="w-5 h-5 pointer-events-none relative z-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
                {inputDate && <div className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full border border-white z-10"></div>}
              </div>

              {/* Time Picker */}
              <div className="relative w-8 h-8 flex items-center justify-center text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-full transition-colors">
                <input 
                   type="time" 
                   value={inputTime}
                   onChange={(e) => setInputTime(e.target.value)}
                   className="absolute inset-0 w-full h-full z-20 opacity-0 cursor-pointer"
                   title="Add Time"
                />
                <svg className="w-5 h-5 pointer-events-none relative z-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                {inputTime && <div className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full border border-white z-10"></div>}
              </div>
               
              {/* Submit Button */}
              <button 
                type="submit" 
                disabled={!inputValue.trim()}
                className={`p-2 rounded-lg ml-1 transition-all transform ${inputValue.trim() ? 'bg-red-500 text-white shadow-md shadow-red-200 scale-100' : 'bg-slate-100 text-slate-300 scale-90'}`}
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" />
                </svg>
              </button>
            </div>
          </div>
        </form>

        {/* List */}
        <div className="space-y-3">
          {displayedTodos.map(todo => (
            <TodoItem 
              key={todo.id} 
              todo={todo} 
              onToggle={toggleTodo} 
              onDelete={deleteTodo} 
              onBreakdown={handleBreakdown}
              onEdit={handleEdit}
              onToggleStar={toggleStar}
              isBreakingDown={breakingDownId === todo.id}
            />
          ))}

          {todos.length === 0 && appState !== AppState.PROCESSING && (
             <div className="text-center py-16 opacity-50">
               <div className="text-6xl mb-4">🏴‍☠️</div>
               <p className="font-black text-xl text-slate-400 uppercase tracking-widest">No tasks yet!</p>
               <p className="text-sm text-slate-400 mt-2">Set sail for adventure.</p>
             </div>
          )}
        </div>

        {/* Processing Indicator */}
        {appState === AppState.PROCESSING && (
           <div className="fixed bottom-32 left-1/2 -translate-x-1/2 bg-slate-900/90 backdrop-blur px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-4 z-50 border border-slate-800">
              <div className="flex gap-1.5">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-yellow-500 rounded-full animate-bounce delay-100"></div>
                <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce delay-200"></div>
              </div>
              <span className="text-xs font-bold text-white uppercase tracking-wider">Listening to Captain...</span>
           </div>
        )}
        
        {/* Clear Completed */}
        {hasCompleted && (filter === 'all' || filter === 'completed') && (
          <div className="mt-12 flex justify-center">
             <button 
               onClick={clearCompleted}
               className={`text-xs font-bold uppercase tracking-widest transition-colors px-6 py-3 rounded-xl border-2 ${isClearConfirming ? 'bg-red-50 text-red-600 border-red-200 animate-pulse' : 'text-slate-400 border-dashed border-slate-300 hover:border-red-300 hover:text-red-400 bg-white/50'}`}
             >
               {isClearConfirming ? "Burn the archives?" : "Clear Completed"}
             </button>
          </div>
        )}

      </main>

      {/* Minimal Toast */}
      <div className={`fixed top-6 left-1/2 transform -translate-x-1/2 bg-slate-900 text-white text-sm px-6 py-3 rounded-full shadow-2xl z-50 flex items-center gap-4 transition-all duration-500 ${showUndo ? 'translate-y-0 opacity-100' : '-translate-y-10 opacity-0 pointer-events-none'}`}>
        <span className="font-bold text-red-400">Task Deleted!</span>
        <button onClick={handleUndo} className="text-white hover:text-red-200 font-bold uppercase text-xs border-b border-white/20 pb-0.5">Undo</button>
      </div>

      <VoiceInput onAudioCaptured={handleAudioCaptured} appState={appState} />
    </div>
  );
};

export default App;