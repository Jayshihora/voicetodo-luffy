import { GoogleGenAI, Type } from "@google/genai";
import { blobToBase64 } from "./audioUtils";

const apiKey = process.env.API_KEY;
// Ensure we fail gracefully if key is missing, though the environment should provide it.
const ai = new GoogleGenAI({ apiKey: apiKey || 'dummy_key' });

export interface ExtractedTask {
  text: string;
  deadline?: string;
  deadlineTime?: string;
}

export interface Quote {
  text: string;
  author: string;
}

export const extractTodosFromAudio = async (audioBlob: Blob): Promise<ExtractedTask[]> => {
  if (!apiKey) {
    console.error("API Key is missing");
    throw new Error("API Key is missing");
  }

  try {
    const base64Audio = await blobToBase64(audioBlob);
    
    // Determine mime type from blob, default to webm if missing
    const mimeType = audioBlob.type || 'audio/webm';
    const today = new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: mimeType,
              data: base64Audio
            }
          },
          {
            text: `The current date is ${today}. Listen to this audio. Extract all actionable todo tasks mentioned. 
            
            1. Identify the task description.
            2. If a specific deadline date is mentioned (e.g., "by tomorrow", "next Friday", "on October 5th"), calculate the exact date in YYYY-MM-DD format.
            3. If a specific time is mentioned (e.g., "at 5pm", "by noon", "14:30"), extract it in 24-hour HH:MM format.

            Return them strictly as a JSON object containing an array of objects under the key 'tasks'. If no tasks are found, return an empty array.`
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            tasks: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  text: { type: Type.STRING, description: "The task description" },
                  deadline: { type: Type.STRING, description: "The calculated deadline in YYYY-MM-DD format, or null if not mentioned." },
                  deadlineTime: { type: Type.STRING, description: "The specific time in HH:MM format, or null if not mentioned." }
                },
                required: ["text"]
              },
              description: "A list of distinct todo items extracted from the audio."
            }
          },
          required: ["tasks"]
        }
      }
    });

    const text = response.text;
    if (!text) return [];

    const parsed = JSON.parse(text);
    return parsed.tasks || [];

  } catch (error) {
    console.error("Error extracting todos:", error);
    throw error;
  }
};

export const breakDownTask = async (taskText: string): Promise<ExtractedTask[]> => {
  if (!apiKey) throw new Error("API Key is missing");
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [{
          text: `You are an expert productivity assistant. The user wants to break down this task: "${taskText}".
          
          Generate 2 to 5 smaller, concrete, actionable subtasks required to complete it.
          Return strictly JSON under key 'tasks'.
          
          If the original task implies a deadline (e.g. "tomorrow"), you may infer deadlines for the subtasks, otherwise leave them null.`
        }]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            tasks: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  text: { type: Type.STRING },
                  deadline: { type: Type.STRING, nullable: true },
                  deadlineTime: { type: Type.STRING, nullable: true }
                },
                required: ["text"]
              }
            }
          }
        }
      }
    });
    
    const text = response.text;
    if (!text) return [];
    const parsed = JSON.parse(text);
    return parsed.tasks || [];
  } catch (e) {
    console.error("Breakdown failed", e);
    return [];
  }
};

export const getLuffyGuidance = async (taskCount: number): Promise<Quote> => {
  if (!apiKey) return { text: "I'm gonna be King of the Pirates!", author: "Monkey D. Luffy" };

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [{
          text: `You are Monkey D. Luffy from One Piece. The user has ${taskCount} tasks left on their todo list.
          
          Give a short, high-energy, shouting motivational quote to get them moving!
          - Mention 'Meat', 'Nakama', 'Adventure', or 'Pirate King'.
          - Be encouraging but intense (Gear 5 energy).
          - Maximum 20 words.
          
          Return strictly JSON with keys 'text' and 'author' (which should be 'Monkey D. Luffy').`
        }]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
            type: Type.OBJECT,
            properties: {
                text: { type: Type.STRING },
                author: { type: Type.STRING }
            }
        }
      }
    });
    
    const text = response.text;
    if (!text) return { text: "Yosh! Let's finish this and eat some meat!", author: "Monkey D. Luffy" };
    return JSON.parse(text);
  } catch (e) {
    return { text: "Kaizoku ou ni ore wa naru!", author: "Monkey D. Luffy" };
  }
};