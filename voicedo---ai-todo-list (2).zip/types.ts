export interface Todo {
  id: string;
  text: string;
  completed: boolean;
  createdAt: number;
  deadline?: string;
  deadlineTime?: string;
  isStarred?: boolean;
  reminderOffset?: number; // Number of minutes before the deadline to notify
  reminderSent?: boolean;
}

export interface AudioRecorderState {
  isRecording: boolean;
  audioBlob: Blob | null;
}

export enum AppState {
  IDLE,
  RECORDING,
  PROCESSING,
  ERROR
}

export type FilterOption = 'all' | 'active' | 'completed';
export type SortOption = 'smart' | 'created' | 'deadline' | 'starred';
